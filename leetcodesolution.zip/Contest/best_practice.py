'''




# heap max not maintain the heap property when get the item out of the curernt heap
-> so using the min head (multuiple (-1) if needed) 

# formular: using queu in leetcode
from queue import Queue
q = Queue()
q.put((headID, informTime[headID]))  | q.get  | while(q.empty() is False):

'''