'''

AC 2:

https://leetcode.com/contest/weekly-contest-174


https://leetcode.com/contest/weekly-contest-174/problems/the-k-weakest-rows-in-a-matrix/

https://leetcode.com/contest/weekly-contest-174/problems/reduce-array-size-to-the-half/


https://leetcode.com/contest/weekly-contest-174/problems/maximum-product-of-splitted-binary-tree/


https://leetcode.com/contest/weekly-contest-174/problems/jump-game-v/


***plan:
1) refactor code 01
2) refactor code 02
3) /subtree/ -> sum of subtree -> DFS
4) jump game 1 ,2 , 3
'''